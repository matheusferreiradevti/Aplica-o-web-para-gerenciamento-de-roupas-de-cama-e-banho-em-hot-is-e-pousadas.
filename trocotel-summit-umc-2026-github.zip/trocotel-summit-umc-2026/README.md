# Trocotel — Gestão Inteligente de Roupas de Cama e Banho

**Projeto acadêmico em equipe | 4º Summit UMC 2026 | Análise e Desenvolvimento de Sistemas**

## Sobre o projeto

O Trocotel é uma aplicação web proposta para apoiar o gerenciamento de roupas de cama e banho em hotéis e pousadas. O projeto parte de um problema da rotina hoteleira: o controle manual de toalhas, lençóis e outros materiais pode dificultar o acompanhamento do estoque, gerar perdas e contribuir para falhas nas trocas dos quartos.

A solução busca centralizar o cadastro e o acompanhamento dos materiais, facilitando a visualização das quantidades e de seus status.

## Objetivo

Oferecer uma ferramenta simples para apoiar a organização dos materiais utilizados nos quartos e melhorar o controle operacional de hotéis e pousadas.

## Tecnologias

- **Java Web** — desenvolvimento da aplicação.
- **MySQL** — armazenamento e consulta dos dados.

## Funcionalidades implementadas e testadas no MVP

- Cadastro de materiais pela área da gerência.
- Integração Java Web com MySQL.
- Listagem dinâmica dos materiais cadastrados.
- Edição das quantidades.
- Atualização do status dos materiais.
- Consulta dos itens e suas situações: disponível, em uso, usado e lavando.

## Funcionalidades em desenvolvimento

- Registro das trocas pelos funcionários.
- Histórico de movimentações na interface.
- Integração dos registros de troca com o estoque.

> **Nota sobre a demonstração:** as imagens desta pasta foram extraídas das capturas reais do MVP apresentadas nos slides do Summit (telas 9 a 13). O painel do funcionário exibido no slide 14 está identificado na apresentação como protótipo visual, não como tela testada; por isso, não foi incluído entre as capturas de funcionalidades implementadas.

## Capturas reais do MVP

### Tela inicial
![Tela inicial](imagens/tela-inicial.png)

### Cadastro de materiais
![Cadastro de materiais](imagens/cadastro-de-materiais.png)

### Consulta do estoque
![Consulta do estoque](imagens/consulta-do-estoque.png)

### Confirmação de cadastro
![Confirmação de cadastro](imagens/confirmacao-de-cadastro.png)

### Gerenciamento de materiais
![Gerenciamento de materiais](imagens/gerenciamento-de-materiais.png)

## Minha participação

Participei do desenvolvimento do projeto em equipe e da apresentação no 4º Summit UMC 2026. Durante o evento, apresentei os pontos relacionados ao impacto esperado e ao andamento do projeto, compartilhando a evolução do MVP, as funcionalidades já implementadas e os próximos passos.

A experiência permitiu aplicar conhecimentos da graduação em Análise e Desenvolvimento de Sistemas, além de desenvolver comunicação, colaboração e apresentação de soluções tecnológicas.

## Apresentação

O arquivo PDF utilizado no 4º Summit UMC 2026 está disponível em [`apresentacao/`](apresentacao/Trocotel_Summit_UMC_2026.pdf).

## Equipe

- Julia Siqueira e Silva
- Thayna
- Guilherme
- Ronald
- Matheus

**Orientador:** Adilson da Silva

**Instituição:** Universidade de Mogi das Cruzes (UMC)  
**Curso:** Análise e Desenvolvimento de Sistemas (ADS)  
**Evento:** 4º Summit UMC 2026

---

*Projeto acadêmico desenvolvido em equipe. Este repositório reúne a apresentação e os registros visuais do MVP; o código-fonte não foi incluído porque não foi fornecido neste material.*
